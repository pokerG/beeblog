第 6 课：评论与分类显示
==========================

### 基本信息

- 课程时长：51:50
- 在线观看：[土豆网](http://www.tudou.com/programs/view/JFL7PGjpz4Q/) [优才网](http://www.ucai.cn/course/chapter/87/3267/5967) [网易云课堂](http://study.163.com/course/courseLearn.htm?courseId=328001#/learn/video?lessonId=548094&courseId=328001)

### 课程大纲

	[00:00] 知识回顾
	[07:51] 添加评论
	[28:25] 删除评论
	[38:24] 文章分类显示
	[47:28] 课堂作业
	
### 补充说明

暂无说明

### 相关链接

暂无链接

### 课程链接
 
- [第 5 课：文章的添加与删除](../lecture5/lecture5.md)
- [第 7 课：为文章增加标签](../lecture7/lecture7.md)

第 10 课：自建 HTTP 中间件
==========================

### 基本信息

- 课程时长：31:51
- 在线观看：[土豆网](http://www.tudou.com/programs/view/zxRhEOPz7BI/) [优才网](http://www.ucai.cn/course/chapter/87/3267/6815) [网易云课堂]

### 课程大纲

	[00:00] 知识回顾
	[00:45] 以类型形式
	[10:29] 以函数形式
	[17:07] 追加响应内容
	[21:04] 自定义响应
	
### 补充说明

暂无说明

### 相关链接

- [Writing HTTP Middleware in Go](http://justinas.org/writing-http-middleware-in-go/?utm_campaign=Manong_Weekly_Issue_7&utm_medium=EDM&utm_source=Manong_Weekly) 技术翻译：[用 Go 语言写 HTTP 中间件](http://blog.jobbole.com/53265/)

### 课程链接

- [第 9 课：国际化支持](../lecture9/lecture9.md)
- [第 11 课：简易的 RPC 实现](../lecture11/lecture11.md)

第1课：博客项目设计
==========================

### 基本信息

- 课程时长：20:33
- 在线观看：[土豆网](http://www.tudou.com/programs/view/gXZb9tGNsGU/) [优才网](http://www.ucai.cn/course/chapter/87/3267/4710) [网易云课堂]

### 课程大纲

	[00:00] 课程简介
	[03:20] 课程相关工具配置
	[08:10] MVC 项目创建
	[11:00] 数据库结构设计与 Qbs
	[13:20] 控制器设计与 beego
	[19:00] 前端相关问题
	
### 补充说明

暂无说明

### 相关链接

- 下载 Sublime Text 3：[官方网站](http://www.sublimetext.com/3)
- [Sublime Text 2 入门及技巧](http://lucifr.com/2011/08/31/sublime-text-2-tricks-and-tips/)
- [Sublime + GoSublime 配置教程](http://my.oschina.net/Obahua/blog/110767)
- [go-sqlite3 安装教程](http://my.oschina.net/Obahua/blog/129689)
- [beego](https://github.com/astaxie/beego)
- [Qbs](https://github.com/coocood/qbs)
- [Bootstrap](http://bootcss.com)
- [Go 初学者常问的问题FAQ](http://bbs.studygolang.com/thread-67-1-1.html)
- [Go 开发问题索引贴](http://bbs.mygolang.com/thread-458-1-1.html)

### 课程链接

- [第2课：初窥 Web 开发](../lecture2/lecture2.md)
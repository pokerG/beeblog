第 5 课：文章的添加与删除
==========================

### 基本信息

- 课程时长：1:03:30
- 在线观看：[土豆网](http://www.tudou.com/programs/view/g9q30NSRI8c/) [优才网](http://www.ucai.cn/course/chapter/87/3267/4800) [网易云课堂](http://study.163.com/course/courseLearn.htm?courseId=328001#/learn/video?lessonId=502075&courseId=328001)

### 课程大纲

	[00:00] 知识回顾
	[01:38] 添加文章
	[21:04] 浏览文章
	[41:38] 修改文章
	[50:50] 删除文章
	[56:24] Go 表单处理讲解
	[62:36] 课堂作业
	
### 补充说明

暂无说明

### 相关链接

暂无链接

### 课程链接

- [第 4 课：登录及分类管理](../lecture4/lecture4.md)
- [第 6 课：评论与分类显示](../lecture6/lecture6.md)
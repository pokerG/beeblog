第 7 课：为文章添加标签
==========================

### 基本信息

- 课程时长：50:34
- 在线观看：[土豆网](http://www.tudou.com/programs/view/QpE6LM3Ie2k/) [优才网](http://www.ucai.cn/course/chapter/87/3267/6400) [网易云课堂](http://study.163.com/course/courseLearn.htm?courseId=328001#/learn/video?lessonId=626001&courseId=328001)

### 课程大纲

	[00:00] 知识回顾
	[27:53] 增加及修改标签
	[41:00] 按标签浏览
	
### 补充说明

暂无说明

### 相关链接

暂无链接

### 课程链接

- [第 6 课：评论与分类显示](../lecture6/lecture6.md)
- [第 8 课：文章附件上传](../lecture8/lecture8.md)

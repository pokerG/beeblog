第 12 课：Go Web 扩展学习
==========================

### 基本信息

- 课程时长：18:09
- 在线观看：[土豆网](http://www.tudou.com/programs/view/oXtAdeVy-yo/) [优才网](http://www.ucai.cn/course/chapter/87/3267/6817) [网易云课堂]

### 课程大纲

	[00:00] 知识回顾
	[01:29] REST 概述
	[05:33] WebSocket 演示
	[14:23] 未来教程计划
	
### 补充说明

暂无说明

### 相关链接

- [REST 简介](https://github.com/astaxie/build-web-application-with-golang/blob/master/ebook/08.3.md)
- [WebSocket 简介](https://github.com/astaxie/build-web-application-with-golang/blob/master/ebook/08.2.md)
- [Gorilla WebSocket 包](http://gowalker.org/github.com/gorilla/websocket)

### 课程链接

- [第 11 课：简易的 RPC 实现](../lecture11/lecture11.md)

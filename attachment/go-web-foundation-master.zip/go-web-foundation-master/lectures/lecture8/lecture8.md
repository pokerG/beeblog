第 8 课：文章附件上传
==========================

### 基本信息

- 课程时长：35:18
- 在线观看：[土豆网](http://www.tudou.com/programs/view/UqVp_KqSc_A/) [优才网](http://www.ucai.cn/course/chapter/87/3267/6401) [网易云课堂](http://study.163.com/course/courseLearn.htm?courseId=328001#/learn/video?lessonId=626002&courseId=328001)

### 课程大纲

	[00:00] 知识回顾
	[01:05] beego 上传文件
	[33:37] 课堂作业
	
### 补充说明

暂无说明

### 相关链接

暂无链接

### 课程链接

- [第 7 课：为文章增加标签](../lecture7/lecture7.md)
- [第 9 课：国际化支持](../lecture9/lecture9.md)

第2课：初窥 Web 开发
==========================

### 基本信息

- 课程时长：43:31
- 在线观看：[土豆网](http://www.tudou.com/programs/view/sqZoUrqNJno/) [优才网](http://www.ucai.cn/course/chapter/87/3267/4732) [网易云课堂]

### 课程大纲

	[00:00] beego 版 “Hello World”
	[06:30] 探究 Go HTTP 控制器
	[30:45] 使用 bee 初始化项目
	[35:55] beego 配置管理
	[39:16] beego 默认参数
	[41:25] beego 日志级别
	
### 补充说明

暂无说明

### 相关链接

- [bee 工具](https://github.com/astaxie/bee)
- [beego 官网](http://beego.me)
- [beego 配置管理](http://beego.me/docs/Reference_AppConf)
- [beego 日志级别](http://beego.me/docs/Operational_Logging)

### 课程链接

- [第1课：博客项目设计](../lecture1/lecture1.md)
- [第3课：模板用法讲解](../lecture3/lecture3.md)
第 11 课：简易的 RPC 实现
==========================

### 基本信息

- 课程时长：28:37
- 在线观看：[土豆网](http://www.tudou.com/programs/view/QdpzbVZsnN0/) [优才网](http://www.ucai.cn/course/chapter/87/3267/6816) [网易云课堂]

### 课程大纲

	[00:00] 知识回顾
	[01:39] HTTP RPC
	[19:59] TCP RPC
	[24:36] JSON RPC
	
### 补充说明

暂无说明

### 相关链接

- [Go RPC 简介](https://github.com/astaxie/build-web-application-with-golang/blob/master/ebook/08.4.md)
- [Go RPC Inside (server)](http://www.bigendian123.com/go/2013/09/01/go-rpcserver-inside/)
- [Go RPC Inside (client)](http://www.bigendian123.com/go/2013/08/28/go-rpcclient-inside/)

### 课程链接

- [第 10 课：自建 HTTP 中间件](../lecture10/lecture10.md)
- [第 12 课：Go Web 扩展学习](../lecture12/lecture12.md)
